# dsmr-telegram-parser

Type-safe DSMR telegram parser — parse smart meter messages into TypeScript objects with friendly field names

## Installation

```bash
npm install dsmr-telegram-parser
```

## Usage

```typescript
import { parseTelegram } from 'dsmr-telegram-parser';

const rawTelegram = `/ISk5\\2MT382-1000

1-3:0.2.8(50)
0-0:1.0.0(210413084817S)
0-0:96.1.1(4530303434303037313331373931363138)
1-0:1.8.1(001234.567*kWh)
1-0:1.8.2(002345.678*kWh)
1-0:2.8.1(000123.456*kWh)
1-0:2.8.2(000234.567*kWh)
0-0:96.14.0(0002)
1-0:1.7.0(01.234*kW)
1-0:2.7.0(00.000*kW)
0-0:96.7.21(00003)
0-0:96.7.9(00001)
1-0:99.97.0(1)(0-0:96.7.19)(000101000001W)(2147483647*s)
1-0:32.32.0(00001)
1-0:52.32.0(00001)
1-0:72.32.0(00000)
1-0:32.36.0(00000)
1-0:52.36.0(00000)
1-0:72.36.0(00000)
0-0:96.13.0()
1-0:32.7.0(220.1*V)
1-0:52.7.0(219.8*V)
1-0:72.7.0(221.3*V)
1-0:31.7.0(001*A)
1-0:51.7.0(002*A)
1-0:71.7.0(003*A)
1-0:21.7.0(01.234*kW)
1-0:41.7.0(00.000*kW)
1-0:61.7.0(00.000*kW)
1-0:22.7.0(00.000*kW)
1-0:42.7.0(00.000*kW)
1-0:62.7.0(00.000*kW)
0-1:24.1.0(003)
0-1:96.1.0(4730303538353330313331373939373131)
0-1:24.2.1(210413084501S)(04567.890*m3)
!7A36
`;

const telegram = parseTelegram(rawTelegram);

console.log(telegram.identification);              // 'ISk5\2MT382-1000'
console.log(telegram.dsmrVersion);                 // '50'
console.log(telegram.timestamp);                   // Date object (UTC)
console.log(telegram.electricityDeliveredTariff1); // 1234.567 (kWh)
console.log(telegram.electricityDeliveredTariff2); // 2345.678 (kWh)
console.log(telegram.currentPowerUsage);           // 1.234 (kW)
console.log(telegram.voltageL1);                   // 220.1 (V)
console.log(telegram.currentL1);                   // 1 (A)
console.log(telegram.gasMeter?.reading);           // 4567.890 (m3)
console.log(telegram.crcValid);                    // true
```

## API

### `parseTelegram(telegram: string, options?: ParseOptions): DsmrTelegram`

Parses a DSMR 5 telegram string into a structured object.

**Parameters:**
- `telegram` – The raw telegram string
- `options.validateCrc` – Whether to validate the CRC checksum (default: `true`)

**Throws an error when:**
- The telegram does not start with `/`
- The telegram is missing the `!` terminator

### `validateCrc(telegram: string): boolean`

Validates the CRC16 checksum of a telegram.

### `crc16(data: string): number`

Calculates the CRC16/IBM checksum of a string.

## Return fields (`DsmrTelegram`)

| Field | Type | Description |
|-------|------|-------------|
| `identification` | `string` | Meter identification string |
| `dsmrVersion` | `string` | DSMR version (e.g. `"50"`) |
| `timestamp` | `Date` | Telegram timestamp (UTC) |
| `equipmentIdentifier` | `string` | Equipment identifier |
| `electricityDeliveredTariff1` | `number` | Electricity usage tariff 1 (kWh) |
| `electricityDeliveredTariff2` | `number` | Electricity usage tariff 2 (kWh) |
| `electricityReturnedTariff1` | `number` | Electricity returned tariff 1 (kWh) |
| `electricityReturnedTariff2` | `number` | Electricity returned tariff 2 (kWh) |
| `activeTariff` | `number` | Active tariff (1 or 2) |
| `currentPowerUsage` | `number` | Current power usage (kW) |
| `currentPowerReturn` | `number` | Current power return (kW) |
| `powerFailures` | `number` | Number of power failures (any phase) |
| `longPowerFailures` | `number` | Number of long power failures |
| `powerFailureEventLog` | `PowerFailureEvent[]` | Power failure event log |
| `voltageSagsL1/L2/L3` | `number` | Voltage sags per phase |
| `voltageSwellsL1/L2/L3` | `number` | Voltage swells per phase |
| `textMessage` | `string` | Text message |
| `voltageL1/L2/L3` | `number` | Instantaneous voltage per phase (V) |
| `currentL1/L2/L3` | `number` | Instantaneous current per phase (A) |
| `powerUsageL1/L2/L3` | `number` | Power usage per phase (kW) |
| `powerReturnL1/L2/L3` | `number` | Power return per phase (kW) |
| `gasMeter` | `GasMeter \| null` | Gas meter data |
| `crc` | `string` | CRC value from telegram |
| `crcValid` | `boolean` | Whether the CRC is valid |
| `raw` | `string` | Raw telegram string |

### `GasMeter`

| Field | Type | Description |
|-------|------|-------------|
| `deviceType` | `number` | Device type (e.g. 3 = gas) |
| `identifier` | `string` | Gas meter identifier |
| `timestamp` | `Date` | Timestamp of the reading (UTC) |
| `reading` | `number` | Gas meter reading (m³) |

## License

MIT
